/*
 * Copyright (C) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.android.animationplayground;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.android.animationplayground.sample.Sample;

public class SampleListFragment extends Fragment {

    public static SampleListFragment newInstance() {
        return new SampleListFragment();
    }

    Listener mListener;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_sample_list, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        final RecyclerView list = (RecyclerView) view.findViewById(R.id.list);
        list.setLayoutManager(
                new LinearLayoutManager(list.getContext(), LinearLayoutManager.VERTICAL, false));
        list.setAdapter(new Adapter());
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mListener = (Listener) context;
    }

    @Override
    public void onDetach() {
        mListener = null;
        super.onDetach();
    }

    public interface Listener {
        void onSampleSelected(Sample sample);
    }

    private class ViewHolder extends RecyclerView.ViewHolder implements
            View.OnClickListener {

        TextView text;

        ViewHolder(LayoutInflater inflater, ViewGroup container) {
            super(inflater.inflate(R.layout.item_sample, container, false));
            text = (TextView) itemView.findViewById(R.id.text);
            text.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (mListener != null) {
                mListener.onSampleSelected(Sample.values()[getAdapterPosition()]);
            }
        }

    }

    private class Adapter extends RecyclerView.Adapter<ViewHolder> {

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            return new ViewHolder(LayoutInflater.from(parent.getContext()), parent);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            final Sample sample = Sample.values()[position];
            holder.text.setEnabled(Build.VERSION.SDK_INT >= sample.getMinSdkVersion());
            holder.text.setText(sample.getName());
        }

        @Override
        public int getItemCount() {
            return Sample.values().length;
        }

    }

}
