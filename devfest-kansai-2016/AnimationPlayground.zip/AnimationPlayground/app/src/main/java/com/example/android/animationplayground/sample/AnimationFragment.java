/*
 * Copyright (C) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.android.animationplayground.sample;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import com.example.android.animationplayground.R;

public class AnimationFragment extends Fragment {

    static final Sample.Creator CREATOR = new Sample.Creator() {
        @Override
        public Fragment create() {
            return new AnimationFragment();
        }
    };

    private View mTarget;

    private Animation mTranslate;
    private Animation mFadeOut;
    private Animation mZoomIn;
    private Animation mRotate;

    private final View.OnClickListener mOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            mTarget.clearAnimation();
            switch (view.getId()) {
                case R.id.translate:
                    mTarget.startAnimation(mTranslate);
                    break;
                case R.id.alpha:
                    mTarget.startAnimation(mFadeOut);
                    break;
                case R.id.scale:
                    mTarget.startAnimation(mZoomIn);
                    break;
                case R.id.rotate:
                    mTarget.startAnimation(mRotate);
                    break;
            }
        }
    };

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final Context context = getContext();
        int duration = context.getResources().getInteger(R.integer.duration_long);
        mTranslate = AnimationUtils.loadAnimation(context, R.anim.translate);
        mTranslate.setDuration(duration);
        mFadeOut = AnimationUtils.loadAnimation(context, android.R.anim.fade_out);
        mFadeOut.setDuration(duration);
        mZoomIn = AnimationUtils.loadAnimation(context, R.anim.zoom_in);
        mZoomIn.setDuration(duration);
        mRotate = AnimationUtils.loadAnimation(context, R.anim.rotate);
        mRotate.setDuration(duration);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_animation, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mTarget = view.findViewById(R.id.target);
        view.findViewById(R.id.translate).setOnClickListener(mOnClickListener);
        view.findViewById(R.id.alpha).setOnClickListener(mOnClickListener);
        view.findViewById(R.id.scale).setOnClickListener(mOnClickListener);
        view.findViewById(R.id.rotate).setOnClickListener(mOnClickListener);
    }

}
