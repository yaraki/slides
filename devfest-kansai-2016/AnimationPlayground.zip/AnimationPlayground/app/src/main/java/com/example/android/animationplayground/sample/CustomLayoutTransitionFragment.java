/*
 * Copyright (C) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.android.animationplayground.sample;

import android.animation.LayoutTransition;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.annotation.TargetApi;
import android.support.v4.app.Fragment;
import android.widget.LinearLayout;

@TargetApi(11)
public class CustomLayoutTransitionFragment extends LayoutTransitionFragment {

    public static Sample.Creator CREATOR = new Sample.Creator() {
        @Override
        public Fragment create() {
            return new CustomLayoutTransitionFragment();
        }
    };

    @Override
    protected void customize(LinearLayout box) {
        final LayoutTransition transition = new LayoutTransition();
        transition.setAnimator(LayoutTransition.APPEARING,
                ObjectAnimator.ofPropertyValuesHolder((Object) null,
                        PropertyValuesHolder.ofFloat("translationX", 500.f, 0.f),
                        PropertyValuesHolder.ofFloat("alpha", 0.f, 1.f)));
        transition.setAnimator(LayoutTransition.DISAPPEARING,
                ObjectAnimator.ofPropertyValuesHolder((Object) null,
                        PropertyValuesHolder.ofFloat("translationX", 500f),
                        PropertyValuesHolder.ofFloat("alpha", 0.f)));
        box.setLayoutTransition(transition);
    }

}
