/*
 * Copyright (C) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.android.animationplayground.sample;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.example.android.animationplayground.R;

import java.util.Random;

public class LayoutTransitionFragment extends Fragment {

    private final Random mRandom = new Random();

    public static Sample.Creator CREATOR = new Sample.Creator() {
        @Override
        public Fragment create() {
            return new LayoutTransitionFragment();
        }
    };

    private final View.OnClickListener mOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            final int childCount = mBox.getChildCount();
            switch (view.getId()) {
                case R.id.add:
                    View v = LayoutInflater.from(getContext()).inflate(R.layout.item, mBox, false);
                    v.setBackgroundColor(Data.COLORS[mRandom.nextInt(Data.COLORS.length)]);
                    if (childCount > 0) {
                        mBox.addView(v, mRandom.nextInt(childCount));
                    } else {
                        mBox.addView(v);
                    }
                    break;
                case R.id.remove:
                    if (childCount > 0) {
                        mBox.removeViewAt(mRandom.nextInt(childCount));
                    }
                    break;
            }
        }
    };

    private LinearLayout mBox;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_layout_transition, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        mBox = (LinearLayout) view.findViewById(R.id.box);
        customize(mBox);
        view.findViewById(R.id.add).setOnClickListener(mOnClickListener);
        view.findViewById(R.id.remove).setOnClickListener(mOnClickListener);
    }

    protected void customize(LinearLayout box) {
    }

}
