/*
 * Copyright (C) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.android.animationplayground.sample;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.annotation.TargetApi;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.android.animationplayground.R;

@TargetApi(11)
public class ObjectAnimatorFragment extends Fragment {

    public static Sample.Creator CREATOR = new Sample.Creator() {
        @Override
        public Fragment create() {
            return new ObjectAnimatorFragment();
        }
    };

    private final View.OnClickListener mOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.slide:
                    if (mSlide == null) {
                        mSlide = AnimatorInflater.loadAnimator(getContext(), R.animator.slide);
                        mSlide.setTarget(mTarget);
                    } else if (mSlide.isRunning()) {
                        mSlide.cancel();
                    }
                    mSlide.start();
                    break;
            }
        }
    };

    private View mTarget;
    private Animator mSlide;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_object_animator, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        mTarget = view.findViewById(R.id.target);
        view.findViewById(R.id.slide).setOnClickListener(mOnClickListener);
    }

}
