/*
 * Copyright (C) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.android.animationplayground.sample;

import android.support.v4.app.Fragment;

public enum Sample {

    ANIMATION("Animation", AnimationFragment.CREATOR, 9),
    TEXT_SWITCHER("TextSwitcher", TextSwitcherFragment.CREATOR, 9),
    ACTIVITY_ANIMATION("Activity Animation", ActivityAnimationFragment.CREATOR, 9),
    VALUE_ANIMATOR("ValueAnimator", ValueAnimatorFragment.CREATOR, 11),
    OBJECT_ANIMATOR("ObjectAnimator", ObjectAnimatorFragment.CREATOR, 11),
    SIMPLE_OBJECT_ANIMATOR("Simple ObjectAnimator", SimpleObjectAnimatorFragment.CREATOR, 11),
    PROPERTY_OBJECT_ANIMATOR("ObjectAnimator with Property", PropertyObjectAnimatorFragment.CREATOR,
            14),
    ANIMATOR_SET("AnimatorSet", AnimatorSetFragment.CREATOR, 11),
    VIEW_PROPERTY_ANIMATOR("ViewPropertyAnimator", ViewPropertyAnimatorFragment.CREATOR, 9),
    LAYOUT_TRANSITION("LayoutTransition", LayoutTransitionFragment.CREATOR, 9),
    CUSTOM_LAYOUT_TRANSITION("Custom LayoutTransition", CustomLayoutTransitionFragment.CREATOR, 11),
    BEGIN_DELAYED_TRANSITION("beginDelayedTransition", BeginDelayedTransitionFragment.CREATOR, 14),
    CUSTOM_TRANSITION("Custom Transition", CustomTransitionFragment.CREATOR, 14),;

    private final String mName;
    private final Creator mCreator;
    private final int mMinSdkVersion;

    Sample(String name, Creator creator, int minSdkVersion) {
        mName = name;
        mCreator = creator;
        mMinSdkVersion = minSdkVersion;
    }

    public String getName() {
        return mName;
    }

    public Fragment createFragment() {
        return mCreator.create();
    }

    public int getMinSdkVersion() {
        return mMinSdkVersion;
    }

    public interface Creator {
        Fragment create();
    }

}
