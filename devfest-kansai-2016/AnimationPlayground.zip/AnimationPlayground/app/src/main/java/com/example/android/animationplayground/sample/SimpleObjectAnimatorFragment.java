/*
 * Copyright (C) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.android.animationplayground.sample;

import android.animation.ObjectAnimator;
import android.annotation.TargetApi;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.TextView;

import com.example.android.animationplayground.R;

@TargetApi(11)
public class SimpleObjectAnimatorFragment extends Fragment {

    public static Sample.Creator CREATOR = new Sample.Creator() {
        @Override
        public Fragment create() {
            return new SimpleObjectAnimatorFragment();
        }
    };

    private final View.OnClickListener mOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.start:
                    final ObjectAnimator prev = (ObjectAnimator) mText.getTag();
                    if (prev != null && prev.isRunning()) {
                        prev.cancel();
                    }
                    final Target target = new Target(10, mText);
                    final ObjectAnimator animator = ObjectAnimator
                            .ofInt(target, "value", 110)
                            .setDuration(5000);
                    animator.setInterpolator(new LinearInterpolator());
                    mText.setTag(animator);
                    animator.start();
                    break;
            }
        }
    };

    private TextView mText;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_simple_object_animator, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        mText = (TextView) view.findViewById(R.id.text);
        view.findViewById(R.id.start).setOnClickListener(mOnClickListener);
    }

    private static class Target {

        private int mValue;

        private final TextView mText;

        Target(int value, TextView text) {
            mValue = value;
            mText = text;
        }

        // This is called by the ObjectAnimator
        @SuppressWarnings("unused")
        void setValue(int value) {
            mValue = value;
            mText.setText(String.valueOf(value));
        }

        // This is called by the ObjectAnimator
        @SuppressWarnings("unused")
        int getValue() {
            return mValue;
        }

    }

}
