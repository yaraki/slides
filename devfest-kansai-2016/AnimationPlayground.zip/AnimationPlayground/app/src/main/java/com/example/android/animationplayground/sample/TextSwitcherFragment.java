/*
 * Copyright (C) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.android.animationplayground.sample;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextSwitcher;
import android.widget.ViewSwitcher;

import com.example.android.animationplayground.R;

public class TextSwitcherFragment extends Fragment {

    private static final String STATE_COUNT = "count";

    public static Sample.Creator CREATOR = new Sample.Creator() {
        @Override
        public Fragment create() {
            return new TextSwitcherFragment();
        }
    };

    private final View.OnClickListener mOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.change:
                    mCount = (mCount + 1) % Data.CHEESES.length;
                    mTextSwitcher.setText(Data.CHEESES[mCount]);
                    break;
            }
        }
    };

    private int mCount;
    private TextSwitcher mTextSwitcher;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_text_switcher, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        if (savedInstanceState != null) {
            mCount = savedInstanceState.getInt(STATE_COUNT);
        }
        mTextSwitcher = (TextSwitcher) view.findViewById(R.id.text);
        mTextSwitcher.setFactory(new ViewSwitcher.ViewFactory() {
            @Override
            public View makeView() {
                return LayoutInflater.from(getContext())
                        .inflate(R.layout.switcher_text, mTextSwitcher, false);
            }
        });
        mTextSwitcher.setText(Data.CHEESES[0]);
        final Context context = getContext();
        mTextSwitcher.setInAnimation(context, R.anim.text_in);
        mTextSwitcher.setOutAnimation(context, R.anim.text_out);
        view.findViewById(R.id.change).setOnClickListener(mOnClickListener);
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(STATE_COUNT, mCount);
    }

}
